﻿namespace RistovskiNikolaCsharpLab3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("-> Ristovski Nikola 19347\n==================================\n\n-> Za a unesite -1 za kraj programa!\n\n");

            int a = 0;
            int b = 0;

            while (a != -1)
            {
                try
                {
                    Console.Write("\n\n==================================\n\n-> Unesite dimenzije pravougaonika:\n\n\t\ta -> ");

                    a = int.Parse(Console.ReadLine()!);
                    Console.Write("\t\tb -> ");
                    b = int.Parse(Console.ReadLine()!);

                    if (a < 1 || b < 1)
                    {
                        Console.WriteLine("\n-> Dimenzije moraju biti pozitivni celi brojevi!\n");
                    }
                    else
                    {
                        //Dynamic resenje:

                        Console.WriteLine("\n-> Testiramo [DYNAMIC] verziju algoritma:\n");
                        int[] dynamicRes = Pravougaonik.IsekcajNaKvadrateDynamic(a, b);
                        Console.WriteLine($"\t-> Pravougaonik: {a} x {b} ----> {dynamicRes.Length} kvadrata.");
                        Console.Write("\n\t-> ");
                        for (int i = 0; i < dynamicRes.Length; i++)
                        {
                            Console.Write($"[{dynamicRes[i]}x{dynamicRes[i]}] ");
                        }

                        //Greedy resenje:

                        Console.WriteLine("\n\n-> Testiramo [GREEDY] verziju algoritma:\n");
                        int[] greedyRes = Pravougaonik.IseckajNaKvadrateGreedy(a, b);
                        Console.WriteLine($"\t-> Pravougaonik: {a} x {b} ----> {greedyRes.Length} kvadrata.");
                        Console.Write("\n\t-> ");
                        for(int i = 0; i < greedyRes.Length; i++)
                        {
                            Console.Write($"[{greedyRes[i]}x{greedyRes[i]}] ");
                        }
                    }
                }
                catch (Exception ex) 
                {
                    Console.WriteLine("\nNiste uneli validan format brojeva!");
                }
            }

            Console.WriteLine("\n-> Kraj programa!\n\n");
        }
    }
}

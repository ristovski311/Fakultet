﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RistovskiNikolaCsharpLab3
{
    public class Pravougaonik
    {

        // DINAMICKO RESENJE:


        private static Dictionary<(int, int), List<int>> results = new Dictionary<(int, int), List<int>>();

        //Dictionary nam cuva resenja potproblema kako bismo ustedeli na nepotrebnom ponovnom racunanju istih potproblema


        public static int[] IsekcajNaKvadrateDynamic(int a, int b)
        {
            List<int> res = IseckajNaKvadrateDynamicHelper(a, b);
            return res.ToArray();
        }
    


        private static List<int> IseckajNaKvadrateDynamicHelper(int a, int b)
        {
            if (a == 0 || b == 0)
                return new List<int>();

            int manjaStranica = Math.Min(a, b);
            int vecaStranica = Math.Max(a, b);

            if (results.ContainsKey((manjaStranica, vecaStranica)))
                return results[(manjaStranica, vecaStranica)];

            List<int> listaKvadrataMin = null!;

            for (int i = 1; i <= manjaStranica; i++)
            {
                // Prvo radimo deo horizontalno podeljeno

                List<int> horizontalnoIspod = IseckajNaKvadrateDynamicHelper(vecaStranica - i, manjaStranica);
                List<int> horizontalnoPored = IseckajNaKvadrateDynamicHelper(i, manjaStranica - i);

                List<int> listaKvadrataHorizontalno = new List<int>();

                listaKvadrataHorizontalno.AddRange(horizontalnoIspod); //Dodajemo one koji su iseceni od ispod
                listaKvadrataHorizontalno.AddRange(horizontalnoPored); //Plus oni koji su iseceni pored
                listaKvadrataHorizontalno.Add(i);                //Ovde dodajemo taj novi kvadrat duzine stranice i u listu

                // A sada vertikalno podeljeno pa poredimo kasnije

                List<int> vertikalnoIspod = IseckajNaKvadrateDynamicHelper(vecaStranica - i, i);
                List<int> vertikalnoPored = IseckajNaKvadrateDynamicHelper(vecaStranica, manjaStranica - i);

                List<int> listaKvadrataVertikalno = new List<int>();
                listaKvadrataVertikalno.AddRange(vertikalnoIspod); // Kvadrati dobijeni od ispod
                listaKvadrataVertikalno.AddRange(vertikalnoPored); // I oni dobijeni sa strane
                listaKvadrataVertikalno.Add(i); // Isto kao malopre dodajemo novi odseceni kvadrat stranice i

                // Poredimo ova dva tipa - horizontalno i vertikalno - i onda odlucimo koji je bolji tj koji ima manje kvadrata

                if (listaKvadrataMin == null || listaKvadrataHorizontalno.Count < listaKvadrataMin.Count)
                    listaKvadrataMin = listaKvadrataHorizontalno;
                if (listaKvadrataVertikalno.Count < listaKvadrataMin.Count)
                    listaKvadrataMin = listaKvadrataVertikalno;
            }

            // Cuvamo rezultate koje smo dobili u recnik za kasniju upotrebu

            results[(manjaStranica, vecaStranica)] = listaKvadrataMin!;
            return listaKvadrataMin!;
        }






        // GREEDY RESENJE:


        public static int[] IseckajNaKvadrateGreedy(int a, int b)
        {
            int vecaStranica = a > b ? a : b;
            int manjaStranica = a < b ? a : b;
            List<int> kvadrati = [];


            while(manjaStranica > 0)
            {
                vecaStranica -= manjaStranica; //Odsecen je kvadrat manjaStranica x manjaStranica velicine,
                                               //dakle od duze stranice oduzimamo manju pa nam ostaje 
                                               //pravougaonik dimenzije manjaStranica x (vecaStranica - manjaStranica)

                kvadrati.Add(manjaStranica); //Cuvamo informacije o tome koje su dimenzije tih kvadrata
                                                //Length property ovog niza ce nam dati informaciju o tome
                                                //na koliko kvadrata smo mogli da iseckamo pravougaonik

                if (vecaStranica < manjaStranica)
                    (vecaStranica, manjaStranica) = (manjaStranica, vecaStranica); //Slucaj da je sada manja stranica veca
            }

            return kvadrati.ToArray();
        }
    }
}

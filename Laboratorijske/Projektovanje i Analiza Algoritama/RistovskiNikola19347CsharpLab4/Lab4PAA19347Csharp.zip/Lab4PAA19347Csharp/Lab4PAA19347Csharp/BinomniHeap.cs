﻿
namespace Lab4PAA19347Csharp
{
    public class BinomniHeap
    {
        private Cvor head;

        bool isMinHeap; //Da li je min ili max heap, flag

        public bool HeadNull { get {  return head == null; } }

        public BinomniHeap(bool isMinHeap)
        {
            head = null!;
            this.isMinHeap = isMinHeap;
        }

        private bool Compare(int a, int b)
        {
            if(isMinHeap)
            {
                //U zavisnosti od toga da li smo napravili min ili max heap, imacemo razlicita poredjenja
                //ako je u pitanju min heap, onda vracamo true ako je prvi prosledjeni manji od drugog integera
                
                return a < b;
            }
            else
            {
                //Ako je ipak max heap, onda vracamo true ako je prvi veci od drugog integera!

                return a > b;
            }
        }

        public Cvor MinMax()
        {
            Cvor y = null!;
            Cvor x = head;
            int refNode = isMinHeap ? int.MaxValue : int.MinValue;

            while (x != null)
            {
                if (Compare(x.Key, refNode))
                {
                    refNode = x.Key;
                    y = x;
                }
                x = x.Sibling!;
            }
            return y;
        }

        private void Link(Cvor y, Cvor z)
        {
            y.Parent = z;
            y.Sibling = z.Child;
            z.Child = y;
            z.Degree++;
        }

        private Cvor Merge(Cvor cv1, Cvor cv2)
        {
            if (cv1 == null) return cv2;
            if (cv2 == null) return cv1;

            Cvor head;
            Cvor tail;
            Cvor a = cv1, b = cv2;

            if (a.Degree <= b.Degree)
            {
                head = a;
                a = a.Sibling!;
            }
            else
            {
                head = b!;
                b = b.Sibling!;
            }

            tail = head;

            while (a != null && b != null)
            {
                if (a.Degree <= b.Degree)
                {
                    tail.Sibling = a;
                    a = a.Sibling!;
                }
                else
                {
                    tail.Sibling = b;
                    b = b.Sibling!;
                }
                tail = tail.Sibling;
            }

            tail.Sibling = (a != null) ? a : b;
            return head;
        }

        public BinomniHeap Union(BinomniHeap other)
        {
            BinomniHeap newHeap = new BinomniHeap(this.isMinHeap);
            newHeap.head = Merge(this.head, other.head);

            if (newHeap.head == null) return newHeap;

            Cvor prevX = null!, x = newHeap.head, nextX = x.Sibling!;

            while (nextX != null)
            {
                if (x.Degree != nextX.Degree || (nextX.Sibling != null && nextX.Sibling.Degree == x.Degree))
                {
                    prevX = x;
                    x = nextX;
                }
                else if (Compare(x.Key, nextX.Key))
                {
                    x.Sibling = nextX.Sibling;
                    Link(nextX, x);
                }
                else
                {
                    if (prevX == null)
                        newHeap.head = nextX;
                    else
                        prevX.Sibling = nextX;

                    Link(x, nextX);
                    x = nextX;
                }
                nextX = x.Sibling!;
            }

            return newHeap;
        }

        public void Insert(int key)
        {
            BinomniHeap tempHeap = new BinomniHeap(this.isMinHeap);
            tempHeap.head = new Cvor(key);
            head = Union(tempHeap).head;
        }

        public int ExtractMinMax()
        {
            if (head == null)
            {
                Console.WriteLine("Heap je prazan!");
                return -1;
            }

            Cvor prevMin = null!;
            Cvor refNode = head;
            Cvor current = head;

            while (current.Sibling != null)
            {
                if (Compare(current.Sibling.Key, refNode.Key))
                {
                    prevMin = current;
                    refNode = current.Sibling;
                }
                current = current.Sibling;
            }

            if (prevMin != null)
                prevMin.Sibling = refNode.Sibling;
            else
                head = refNode.Sibling!;

            BinomniHeap tempHeap = new BinomniHeap(this.isMinHeap);
            Cvor child = refNode.Child!;

            while (child != null)
            {
                Cvor next = child.Sibling!;
                child.Sibling = tempHeap.head;
                child.Parent = null;
                tempHeap.head = child;
                child = next;
            }

            head = Union(tempHeap).head;
            return refNode.Key;
        }

        public void DecreaseIncreaseKey(Cvor cvor, int newKey)
        {
            if (isMinHeap)
            {
                if (newKey > cvor.Key)
                {
                    Console.WriteLine("Min heap je! Mora novi kljuc biti manji od trenutnog!");
                    return;
                }
            }
            else
            {
                if (newKey < cvor.Key)
                {
                    Console.WriteLine("Max heap je! Mora novi kljuc biti veci od trenutnog!");
                    return;
                }
            }

            cvor.Key = newKey;
            Cvor y = cvor;
            Cvor z = y.Parent!;

            while (z != null && Compare(y.Key, z.Key))
            {
                int temp = y.Key;
                y.Key = z.Key;
                z.Key = temp;

                y = z;
                z = y.Parent!;
            }
        }

        public void Delete(Cvor node)
        {
            int refInt = isMinHeap ? int.MinValue : int.MaxValue;
            DecreaseIncreaseKey(node, refInt);
            ExtractMinMax();
        }

        public Cvor Find(int key)
        {
            return FindNode(head, key);
        }

        private Cvor FindNode(Cvor cvor, int key)
        {
            if (cvor == null)
                return null!;

            if (cvor.Key == key)
                return cvor;

            Cvor foundNode = FindNode(cvor.Child!, key);
            if (foundNode != null)
                return foundNode;

            return FindNode(cvor.Sibling!, key);
        }

        public void PrintHeap()
        {
            Cvor current = head;

            if (current == null)
            {
                Console.WriteLine("Heap je prazan!");
                return;
            }
            PrintTree(current, 0);
        }

        private void PrintTree(Cvor node, int dep)
        {
            if (node == null)
                return;
            Console.WriteLine(new string(' ', dep * 3) + "|");
            Console.WriteLine(new string(' ', dep*3)  + node.Key + $"[{node.Degree}]");
            PrintTree(node.Child!, dep + 1);
            PrintTree(node.Sibling!, dep);
        }

        public void PrintHeapInFile(string filePath)
        {
            Cvor current = head;

            using (StreamWriter writer = new StreamWriter(filePath))
            {
                if (current == null)
                {
                    writer.WriteLine("Heap je prazan!");
                    return;
                }
                PrintTreeInFile(current, 0, writer);
            }
        }

        private void PrintTreeInFile(Cvor node, int dep, StreamWriter writer)
        {
            if (node == null)
                return;

            writer.WriteLine(new string(' ', dep * 3) + "|");
            writer.WriteLine(new string(' ', dep * 3) + node.Key + $"[{node.Degree}]");
            PrintTreeInFile(node.Child!, dep + 1, writer);
            PrintTreeInFile(node.Sibling!, dep, writer);
        }

    }

}

﻿namespace Lab4PAA19347Csharp
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Ristovski Nikola 19347

            //Kako sam uradio zadatak:

            //Prvo sam implementirao binomni heap uz pomoc prezentacije i interneta
            //Kako je zahtevano:

            // "Svi zadaci se baziraju na skupu slučajno generisanih celih brojeva (int) u opsegu [a, b].
            // Generišite nove nasumične brojeve i upisujte ih u skup dok ne dostigne veličinu N.
            // Nakon svakih k dodatih brojeva, izbacite **najmanji** broj iz skupa."

            //Najlakse je implementirati izbacivanje najmanjeg elementa iz skupa koristeci
            //Min heap. Kako moj zadatak 7 (indeks mi je 19347) kaze:

            //Zadatak 7: Snimite niz kao Max hip.Transformišite ga u Min hip.

            //Neophodno je da imam prvo Max heap, pa onda njega pretvorim u min heap.

            //Veoma je neprakticno iz Max heap-a izbacivati minimalne elemente jer bismo
            //morali da prolazimo kroz prakticno svaki element.
            //Zato ja prvo implementiram min heap, potom generisem uz njegovu pomoc niz od N elemenata
            //i na kraju taj min heap pretvaram u max heap. Kako mi zadatak
            //glasi da MAX heap moram pretvoriti u MIN heap, ja opet taj max heap
            //pretvaram u min heap. Malo je besmisleno ovo raditi, ali je i dobro da pokaze
            //kako je veoma slicno i gotovo jednako vreme potrebno da se iz MIN heap-a 
            //transformise u MAX heap i obrnuto!

            //Nadam se da nisam previse pogresio tematiku zadatka!

            Console.WriteLine("Ristovski Nikola 19347 Lab 4 PAA\n\n");


            //Provera rada heap-a:

            /*BinomniHeap heap = new BinomniHeap(true);
            heap.Insert(10);
            heap.PrintHeap();
            Console.WriteLine("------------------------------------------");
            heap.Insert(20);
            heap.PrintHeap();
            Console.WriteLine("------------------------------------------");
            heap.Insert(5);
            heap.PrintHeap();
            Console.WriteLine("------------------------------------------");
            heap.Insert(4);
            heap.PrintHeap();
            Console.WriteLine("------------------------------------------");
            heap.Insert(3);
            heap.PrintHeap();
            Console.WriteLine("------------------------------------------");
            heap.Insert(8);
            heap.PrintHeap();
            Console.WriteLine("------------------------------------------");
            heap.Insert(9);
            heap.PrintHeap();
            Console.WriteLine("------------------------------------------");
            heap.Insert(11);
            heap.PrintHeap();
            Console.WriteLine("------------------------------------------");
            heap.Insert(-10);
            heap.PrintHeap();
            Console.WriteLine("------------------------------------------");
            //Cvor c = heap.Find(5);
            ////heap.DecreaseIncreaseKey(c, 19);
            //heap.PrintHeap();
            //Console.WriteLine("------------------------------------------");
            Cvor c2 = heap.Find(20);
            heap.Delete(c2);
            Console.WriteLine("\nPosle promene\n");
            heap.PrintHeap();
            Console.WriteLine("------------------------------------------");
            int a = heap.ExtractMinMax();
            Console.WriteLine($"A = {a}\n\n");
            heap.PrintHeap();*/

            int N, a, b, k;

            do
            {
                
                Console.Write("Unesite sledece podatke:\nN = ");
                N = int.Parse(Console.ReadLine());

                if (N < 1000 || N > 10000000)
                    break;

                Console.Write("k = ");
                k = int.Parse(Console.ReadLine());

                Console.Write("a = ");
                a = int.Parse(Console.ReadLine());

                Console.Write("b = ");
                b = int.Parse(Console.ReadLine());

                Console.WriteLine();

                Testing.Test(N, k, a, b);
            } while (true);



        }
    }
}

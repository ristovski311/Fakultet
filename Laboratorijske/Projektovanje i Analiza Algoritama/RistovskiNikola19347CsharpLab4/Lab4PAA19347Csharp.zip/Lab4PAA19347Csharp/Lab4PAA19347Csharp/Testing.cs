﻿using System.Diagnostics;

namespace Lab4PAA19347Csharp
{
    public static class Testing
    {
        public static void Test(int N, int k, int a, int b)
        {

            Random rand = new Random(DateTime.Now.Millisecond);
            int r;
            int e;

            //Posto je neophodno da prvo na svakih k dodavanja izbacimo NAJMANJI element, kako kaze tekst zadatka
            //Mnogo je lakse prvo koristiti MIN heap!

            Stopwatch stopwatch = new Stopwatch();

            stopwatch.Start();

            BinomniHeap heap = new BinomniHeap(true); //false - max Heap, true - min Heap

            for (int i = 0; i < N; i++)
            {
                r = rand.Next(a,b);
                heap.Insert(r);
                if (i % k == 0)
                {
                    e = heap.ExtractMinMax();
                    Console.WriteLine($"Izbacen je element: {e}");
                }
            }

            stopwatch.Stop();
            
            Console.WriteLine($"\n[ Uspesna generacija heap-a ]\n[ {N} elemenata, gde je na svakih {k} izbacen najmanji! ]\n[ Potrebno vreme: {stopwatch.Elapsed.TotalMilliseconds}ms ukupno! ]\n");

            stopwatch.Start();

            BinomniHeap maxHeap = new BinomniHeap(false); //Iz min pretvaramo u max heap

            int num;

            //Pretvaramo u MAX heap jer mi se to trazi u zadatku, da iz MAX pretvorim u MIN, pa prvo iz MIN
            //koji sam koristio jer je zgodniji za izbacivanje svakog k-tog elementa pretvaram u MAX, da bih
            //ga opet pretvorio u min heap
            //Ovo malo nema smisla ali tako sam ga protumacio

            while(!heap.HeadNull)
            {
                num = heap.ExtractMinMax();
                maxHeap.Insert(num);
            }

            stopwatch.Stop();

            maxHeap.PrintHeapInFile("MaxHeap_N" + N + "_k" + k + ".txt");

            Console.WriteLine($"\n[ Min heap je transformisan u Max heap! ]\n[ Bilo je potrebno: {stopwatch.Elapsed.TotalMilliseconds}ms ukupno! ]\n");
        
            stopwatch.Start();

            //Pretvaranje MAX u MIN heap:

            BinomniHeap minHeap = new BinomniHeap(true);

            while (!maxHeap.HeadNull)
            {
                num = maxHeap.ExtractMinMax();
                minHeap.Insert(num);
            }

            stopwatch.Stop();

            minHeap.PrintHeapInFile("MinHeap_N" + N + "_k" + k + ".txt");

            Console.WriteLine($"\n[ Max heap je transformisan u Min heap! ]\n[ Bilo je potrebno: {stopwatch.Elapsed.TotalMilliseconds}ms ukupno! ]\n");


        }

    }
}

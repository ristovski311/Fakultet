﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4PAA19347Csharp
{
    public class Cvor
    {
        public int Key { get; set; }
        public Cvor? Parent { get; set; }
        public Cvor? Sibling { get; set; }

        public Cvor? Child { get; set; }

        public int Degree {  get; set; }

        public Cvor() 
        {
            Key = 0;
            Parent = null;
            Sibling = null;
            Child = null;
            Degree = 0;
        }

        public Cvor(int key)
        {
            Key = key;
            Parent = null;
            Sibling = null;
            Child = null;
            Degree = 0;
        }

    }
}

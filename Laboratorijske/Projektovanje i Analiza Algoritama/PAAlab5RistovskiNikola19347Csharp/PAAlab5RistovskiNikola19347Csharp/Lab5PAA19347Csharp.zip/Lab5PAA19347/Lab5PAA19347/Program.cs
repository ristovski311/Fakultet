﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Lab5PAA19347; // Ensure your namespace matches your project structure

class Program
{
    static void Main(string[] args)
    {
        int N = 10000;
        int k = 2 * N;


        Stopwatch sw = new Stopwatch();

        Console.WriteLine("\n**********\n**********\n**********\n");
        
        sw.Restart();

        Testing.TestAllConnectedToOne(N, k, 4);

        sw.Stop();

        Console.WriteLine($"\nZa N = {N} i k = {k} [{k / N}xN] trebalo je : {sw.Elapsed.TotalSeconds}s!");

        //////
        Console.WriteLine("\n**********\n**********\n**********\n");

        k = 5 * N;

        sw.Restart();

        Testing.TestAllConnectedToOne(N, k, 4);

        sw.Stop();

        Console.WriteLine($"\nZa N = {N} i k = {k} [{k / N}xN] trebalo je : {sw.Elapsed.TotalSeconds}s!");
        //////
        Console.WriteLine("\n**********\n**********\n**********\n");

        k = 10 * N;

        sw.Restart();

        Testing.TestAllConnectedToOne(N, k, 4);

        sw.Stop();

        Console.WriteLine($"\nZa N = {N} i k = {k} [{k / N}xN] trebalo je : {sw.Elapsed.TotalSeconds}s!");
        //////
        Console.WriteLine("\n**********\n**********\n**********\n");

        k = 20 * N;

        sw.Restart();

        Testing.TestAllConnectedToOne(N, k, 4);

        sw.Stop();

        Console.WriteLine($"\nZa N = {N} i k = {k} [{k / N}xN] trebalo je : {sw.Elapsed.TotalSeconds}s!");
        //////
        Console.WriteLine("\n**********\n**********\n**********\n");

        k = 33 * N;

        sw.Restart();

        Testing.TestAllConnectedToOne(N, k, 4);

        sw.Stop();

        Console.WriteLine($"\nZa N = {N} i k = {k} [{k / N}xN] trebalo je : {sw.Elapsed.TotalSeconds}s!");
        //////
        Console.WriteLine("\n**********\n**********\n**********\n");

        k = 50 * N;

        sw.Restart();

        Testing.TestAllConnectedToOne(N, k, 4);

        sw.Stop();

        Console.WriteLine($"\nZa N = {N} i k = {k} [{k / N}xN] trebalo je : {sw.Elapsed.TotalSeconds}s!");
    }
}

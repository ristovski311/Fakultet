﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5PAA19347
{
    public class BinomniHeap
    {
        private CvorBH head;

        bool isMinHeap; //Da li je min ili max heap, flag

        public bool HeadNull { get { return head == null; } }

        public BinomniHeap(bool isMinHeap)
        {
            head = null!;
            this.isMinHeap = isMinHeap;
        }

        private bool Compare(int a, int b)
        {
            if (isMinHeap)
            {
                //U zavisnosti od toga da li smo napravili min ili max heap, imacemo razlicita poredjenja
                //ako je u pitanju min heap, onda vracamo true ako je prvi prosledjeni manji od drugog integera

                return a < b;
            }
            else
            {
                //Ako je ipak max heap, onda vracamo true ako je prvi veci od drugog integera!

                return a > b;
            }
        }

        public CvorBH MinMax()
        {
            CvorBH y = null!;
            CvorBH x = head;
            int refNode = isMinHeap ? int.MaxValue : int.MinValue;

            while (x != null)
            {
                if (Compare(x.Value, refNode))
                {
                    refNode = x.Value;
                    y = x;
                }
                x = x.Sibling!;
            }
            return y;
        }

        private void Link(CvorBH y, CvorBH z)
        {
            y.Parent = z;
            y.Sibling = z.Child;
            z.Child = y;
            z.Degree++;
        }

        private CvorBH Merge(CvorBH cv1, CvorBH cv2)
        {
            if (cv1 == null) return cv2;
            if (cv2 == null) return cv1;

            CvorBH head;
            CvorBH tail;
            CvorBH a = cv1, b = cv2;

            if (a.Degree <= b.Degree)
            {
                head = a;
                a = a.Sibling!;
            }
            else
            {
                head = b!;
                b = b.Sibling!;
            }

            tail = head;

            while (a != null && b != null)
            {
                if (a.Degree <= b.Degree)
                {
                    tail.Sibling = a;
                    a = a.Sibling!;
                }
                else
                {
                    tail.Sibling = b;
                    b = b.Sibling!;
                }
                tail = tail.Sibling;
            }

            tail.Sibling = (a != null) ? a : b;
            return head;
        }

        public BinomniHeap Union(BinomniHeap other)
        {
            BinomniHeap newHeap = new BinomniHeap(this.isMinHeap);
            newHeap.head = Merge(this.head, other.head);

            if (newHeap.head == null) return newHeap;

            CvorBH prevX = null!, x = newHeap.head, nextX = x.Sibling!;

            while (nextX != null)
            {
                if (x.Degree != nextX.Degree || (nextX.Sibling != null && nextX.Sibling.Degree == x.Degree))
                {
                    prevX = x;
                    x = nextX;
                }
                else if (Compare(x.Value, nextX.Value))
                {
                    x.Sibling = nextX.Sibling;
                    Link(nextX, x);
                }
                else
                {
                    if (prevX == null)
                        newHeap.head = nextX;
                    else
                        prevX.Sibling = nextX;

                    Link(x, nextX);
                    x = nextX;
                }
                nextX = x.Sibling!;
            }

            return newHeap;
        }

        public void Insert(Cvor cvor)
        {
            BinomniHeap tempHeap = new BinomniHeap(this.isMinHeap);
            tempHeap.head = new CvorBH(cvor);
            head = Union(tempHeap).head;
        }

        public CvorBH? ExtractMinMax()
        {
            if (head == null)
            {
                Console.WriteLine("Heap je prazan!");
                return null;
            }

            CvorBH prevMin = null!;
            CvorBH refNode = head;
            CvorBH current = head;

            while (current.Sibling != null)
            {
                if (Compare(current.Sibling.Value, refNode.Value))
                {
                    prevMin = current;
                    refNode = current.Sibling;
                }
                current = current.Sibling;
            }

            if (prevMin != null)
                prevMin.Sibling = refNode.Sibling;
            else
                head = refNode.Sibling!;

            BinomniHeap tempHeap = new BinomniHeap(this.isMinHeap);
            CvorBH child = refNode.Child!;

            while (child != null)
            {
                CvorBH next = child.Sibling!;
                child.Sibling = tempHeap.head;
                child.Parent = null;
                tempHeap.head = child;
                child = next;
            }

            head = Union(tempHeap).head;
            return refNode;
        }

        public void DecreaseIncreaseKey(int key, int newValue)
        {

            CvorBH cvor = this.Find(key);

            if(cvor == null)
            {
                Console.WriteLine($"Nije pronadjen cvor sa tim kljucem ({key}) u heap-u!");
                return;
            }    

            if (isMinHeap)
            {
                if (newValue > cvor.Value)
                {
                    Console.WriteLine("Min heap je! Mora novi kljuc biti manji od trenutnog!");
                    return;
                }
            }
            else
            {
                if (newValue < cvor.Value)
                {
                    Console.WriteLine("Max heap je! Mora novi kljuc biti veci od trenutnog!");
                    return;
                }
            }

            cvor.Value = newValue;
            CvorBH y = cvor;
            CvorBH z = y.Parent!;

            while (z != null && Compare(y.Value, z.Value))
            {
                Cvor temp = y.Cvor;
                y.Cvor = z.Cvor;
                z.Cvor = temp;

                y = z;
                z = y.Parent!;
            }
        }

        public void Delete(int key)
        {
            int refInt = isMinHeap ? int.MinValue : int.MaxValue;
            DecreaseIncreaseKey(key, refInt);
            ExtractMinMax();
        }

        public CvorBH? Find(int key)
        {
            return FindNode(head, key);
        }

        private CvorBH FindNode(CvorBH cvorBH, int key)
        {
            if (cvorBH == null)
                return null!;

            if (cvorBH.Cvor.Key == key)
                return cvorBH;

            CvorBH foundNode = FindNode(cvorBH.Child!, key);
            if (foundNode != null)
                return foundNode;

            return FindNode(cvorBH.Sibling!, key);
        }

        public void PrintHeap()
        {
            CvorBH current = head;

            if (current == null)
            {
                Console.WriteLine("Heap je prazan!");
                return;
            }
            PrintTree(current, 0);
        }

        private void PrintTree(CvorBH node, int dep)
        {
            if (node == null)
                return;
            Console.WriteLine(new string(' ', dep * 3) + "|");
            Console.WriteLine(new string(' ', dep * 3) + node.Value + $"[{node.Degree}]");
            PrintTree(node.Child!, dep + 1);
            PrintTree(node.Sibling!, dep);
        }

        public void PrintHeapInFile(string filePath)
        {
            CvorBH current = head;

            using (StreamWriter writer = new StreamWriter(filePath))
            {
                if (current == null)
                {
                    writer.WriteLine("Heap je prazan!");
                    return;
                }
                PrintTreeInFile(current, 0, writer);
            }
        }

        private void PrintTreeInFile(CvorBH node, int dep, StreamWriter writer)
        {
            if (node == null)
                return;

            writer.WriteLine(new string(' ', dep * 3) + "|");
            writer.WriteLine(new string(' ', dep * 3) + node.Value + $"[{node.Degree}]");
            PrintTreeInFile(node.Child!, dep + 1, writer);
            PrintTreeInFile(node.Sibling!, dep, writer);
        }
    }
}

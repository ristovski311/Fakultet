﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Lab5PAA19347
{
    public class Cvor
    {
        public int Key { get;}
        public int Value { get; set; }
        public List<Cvor> Susedi {  get; set; }
        public Cvor? Parent { get; set; }
        public Cvor(int key)
        {
            this.Key = key;
            this.Value = 0;
            this.Parent = null;
            this.Susedi = new List<Cvor>();
        }

        public Cvor(int key, int val)
        {
            this.Key = key;
            this.Value = val;
            this.Parent = null;
            this.Susedi = new List<Cvor>();
        }

        public Cvor()
        {
            this.Key = 1;
            this.Value = 0;
            this.Parent = null;
            this.Susedi = new List<Cvor>();

        }

        public string GetTextual()
        {
            string par = this.Parent == null ? "/" : this.Parent.Key.ToString();
            return $"C: ({this.Key}[v:{this.Value}] [p:{par}])";
        }

        public override bool Equals(object? drugiCvor)
        {
            if (drugiCvor == null || drugiCvor.GetType() != this.GetType())
                return false;

            Cvor drugi = (Cvor)drugiCvor;
            return this.Key == drugi.Key;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Value);
        }
    }
}

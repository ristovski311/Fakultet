﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5PAA19347
{
    internal class Testing
    {
        const int MAX_WEIGHT = 1000;


        //SVI CVOROVI VEZANI ZA JEDNOG


        public static void TestAllConnectedToOne(int N, int k, int pocetniZaPrimov)
        {
            Stopwatch sw = Stopwatch.StartNew();
            Stopwatch sw2 = Stopwatch.StartNew();

            Graf graf = new Graf();

            Random r = new Random(DateTime.Now.Millisecond);

            for (int i = 1; i <= N; i++)
            {
                graf.InsertNode(i);
            }

            int randomCvor = r.Next(1, N + 1);
            int randomTezina;

            for (int i = 1; i <= N; i++)
            {
                if (i != randomCvor)
                {
                    randomTezina = r.Next(1, 200);
                    graf.InsertEdge(i, randomCvor, randomTezina);
                }
            }

            sw.Stop();
            sw2.Stop();
            //Console.WriteLine($"\n=============\nCvorovi su dodati za {sw.Elapsed.TotalSeconds}s!\n============\n");
            sw.Start();
            sw2.Restart();

            //Ovo je prvi nacin na koji sam pokusao da formiram random edges a tako da nema duplikata,
            //medjutim, kako je broj grana rastao tako se znatno smanjivala sansa da dobijem unikat, tako da
            //je trebalo izuzetno puno vremena za izvrsenje, pa sam odusao od ovog metoda, drugi nacin koji koristim
            //je sa listom svih mogucih grana, a onda tu listu randomizujem i idem redom i dodajem ih sve dok broj
            //grana ne dostigne trazeni!

            //while (edgesInserted < k)
            //{
            //    randomTezina = r.Next(1, 200);
            //    randomCvor1 = r.Next(1, N + 1);
            //    randomCvor2 = r.Next(1, N + 1);

            //    if (randomCvor1 == randomCvor2)
            //        continue;

            //    if (this.InsertEdge(randomCvor1, randomCvor2, randomTezina))
            //        edgesInserted++;
            //}


            //U ugnjezdenim for petljama prvo generisem sve moguce grane (parove cvorova) od kojih
            //Samo neke (random odabrane) bivaju ubacene u listu grana grafa

            Random rand = new Random(DateTime.Now.Millisecond);

            int dodatoGrana = 0;

            for (int i = 1; i <= N; i++)
            {
                for (int j = i + 1; j <= N; j++)
                {

                    if (i == randomCvor || j == randomCvor)
                        continue;

                    randomTezina = r.Next(1, MAX_WEIGHT);

                    if (rand.NextDouble() < (double)4 * k / (N * (N - 1) / 2) && dodatoGrana < k)
                    //Ovde je sansa da ova kombinacija iteracija (i,j) bude ubacena u nasu listu mogucih grana randomizovana
                    //Ukupno mogucih grana grafa ima (N * (N - 1)) / 2 a sansa da bude odabrana iteracija je onda k / ukupnoMogucihGrana
                    //Ja ovde dupliram tu sansu kako bih garantovao da na kraju ima barem k grana u listi mogucih grana!
                    { 
                        graf.InsertEdge(i, j, randomTezina);
                        dodatoGrana++;
                    }
                }
            }

            //Ako je slucaj sledeci: N = 100, k=50, nemoguce je kreirati k grana, zbog toga sto je ukupan broj unikatnih grana
            //(100*99)/2 = 4950, tako da je to maksimalni broj grana koje je moguce kreirati a da dva cvora nisu povezana sa vise
            //od jedne grane i da cvor nije povezan sam sa sobom!

            sw.Stop();
            sw2.Stop();

            //Ovo je cisto da potvrdimo da li je doslo do neke greske, da potvrdimo da ima ocekivani broj grana
            //Console.WriteLine($"Gotovo insertovanje, graf sada ima {graf.grane.Count} grana!");
            //Console.WriteLine($"\n=============\nGrane su dodate za {sw2.Elapsed.TotalSeconds}s [Ukupno {sw.Elapsed.TotalSeconds}s]!\n============\n");

            sw.Start();
            sw2.Restart();

            var result = graf.PrimSpreznoStablo(pocetniZaPrimov);

            sw.Stop();
            sw2.Stop();

            Console.WriteLine($"\n=============\nPrimov algoritam je zavrsio za {sw2.Elapsed.TotalSeconds}s [Ukupno {sw.Elapsed.TotalSeconds}s]!\n============\n");

            //Console.WriteLine("\nMST :\n");

            //foreach (Grana g in result)
            //{
            //    Console.WriteLine(g.GetTextual());
            //}

            //Console.WriteLine($"\n=============\nGranama smanjujemo tezine na 1!\n============\n");

            foreach (var g in graf.grane)
                g.Weight = 1;

            //Console.WriteLine($"\n=============\nZapocinjemo Primov algoritam za tezine 1!\n============\n");

            sw.Start();
            sw2.Restart();

            var result2 = graf.PrimSpreznoStablo(pocetniZaPrimov);

            sw.Stop();
            sw2.Stop();

            Console.WriteLine($"\n=============\n[Tezine 1] Primov algoritam je zavrsio za {sw2.Elapsed.TotalSeconds}s [Ukupno {sw.Elapsed.TotalSeconds}s]!\n============\n");


            //Console.WriteLine("\nMST :\n");

            //foreach (Grana g in result)
            //{
            //    Console.WriteLine(g.GetTextual());
            //}
        }


        //DAISYCHAIN


        public static void TestDaisyChain(int N, int k, int pocetniZaPrimov)
        {
            Stopwatch sw = Stopwatch.StartNew();
            Stopwatch sw2 = Stopwatch.StartNew();

            Graf graf = new Graf();

            for (int i = 1; i <= N; i++)
            {
                graf.InsertNode(i);
            }

            sw.Stop();
            sw2.Stop();
            //Console.WriteLine($"\n=============\nCvorovi su dodati za {sw.Elapsed.TotalSeconds}s!\n============\n");
            sw.Start();
            sw2.Restart();


            int randomTezina;
            Random r = new Random();

            for (int i = 1; i < N; i++)
            {
                randomTezina = r.Next(1, 200);

                //Da povezemo prvi i poslednji cvor da bismo dobili daisy chain

                if (i == 1)
                {
                    graf.InsertEdge(i, N, randomTezina);
                }

                graf.InsertEdge(i, i + 1, randomTezina);
            }

            //Console.WriteLine("\nGrane:\n");
            //foreach (var g in graf.grane)
            //    Console.WriteLine(g.GetTextual());

            int dodatoGrana = 0;

            for (int i = 1; i <= N; i++)
            {
                for (int j = i + 2; j <= N; j++) //Time sto stavim da j ide od i+2 garantujem da necemo dobiti (i,i+1) situaciju
                                                 //a kako je j uvek vece od i, ne mozemo da dobijemo ni (i+1, i) tj susede
                {

                    if (i == 1 && j == N) //Ipak moramo da se sacuvamo situacije poslednji i prvi cvor koji smo povezivali u daisy chain
                        continue;

                    randomTezina = r.Next(1, MAX_WEIGHT);

                    if (r.NextDouble() < (double)4 * k / (N * (N - 1) / 2) && dodatoGrana < k)
                    {
                        graf.InsertEdge(i, j, randomTezina);
                        dodatoGrana++;
                    }
                }
            }

            sw.Stop();
            sw2.Stop();
            
            //Console.WriteLine($"Gotovo insertovanje, graf sada ima {graf.grane.Count} grana!");
            //Console.WriteLine($"\n=============\nGrane su dodate za {sw2.Elapsed.TotalSeconds}s [Ukupno {sw.Elapsed.TotalSeconds}s]!\n============\n");

            sw.Start();
            sw2.Restart();

            var result = graf.PrimSpreznoStablo(pocetniZaPrimov);

            sw.Stop();
            sw2.Stop();

            Console.WriteLine($"\n=============\nPrimov algoritam je zavrsio za {sw2.Elapsed.TotalSeconds}s [Ukupno {sw.Elapsed.TotalSeconds}s]!\n============\n");

            //Console.WriteLine("\nMST :\n");

            //foreach (Grana g in result)
            //{
            //    Console.WriteLine(g.GetTextual());
            //}

            //Console.WriteLine($"\n=============\nGranama smanjujemo tezine na 1!\n============\n");

            foreach (var g in graf.grane)
                g.Weight = 1;

            //Console.WriteLine($"\n=============\nZapocinjemo Primov algoritam za tezine 1!\n============\n");

            sw.Start();
            sw2.Restart();

            var result2 = graf.PrimSpreznoStablo(pocetniZaPrimov);

            sw.Stop();
            sw2.Stop();

            Console.WriteLine($"\n=============\n[Tezine 1] Primov algoritam je zavrsio za {sw2.Elapsed.TotalSeconds}s [Ukupno {sw.Elapsed.TotalSeconds}s]!\n============\n");


            //Console.WriteLine("\nMST :\n");

            //foreach (Grana g in result)
            //{
            //    Console.WriteLine(g.GetTextual());
            //}
        }

    }
}

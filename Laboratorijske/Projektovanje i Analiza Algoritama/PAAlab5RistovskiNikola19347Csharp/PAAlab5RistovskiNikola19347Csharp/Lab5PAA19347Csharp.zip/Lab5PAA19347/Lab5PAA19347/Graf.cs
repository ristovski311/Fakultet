﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5PAA19347
{
    public class Graf
    {
        const int MAX_WEIGHT = 1000;

        public Dictionary<int,Cvor> cvorovi; //Zarad brze pretrage koristicemo Dictionary!
        public List<Grana> grane;
        public HashSet<(int,int)> graneHS; // Hash set je jako pogodan za grane kad zelimo da proverimo da li postoji vec ta grana!

        public bool ContainsEdge(int key1, int key2)
        {
            Cvor? cvor1 = cvorovi[key1];
            Cvor? cvor2 = cvorovi[key2];
        
            if(cvor1 == null || cvor2 == null)
                return false;

            if (graneHS.Contains((cvor1.Key, cvor2.Key)) || graneHS.Contains((cvor2.Key, cvor1.Key)))
                    return true;
            else
                return false;
        }

        public Graf()
        {
            this.cvorovi = new Dictionary<int, Cvor>();
            this.grane = new List<Grana>();
            this.graneHS = new HashSet<(int, int)>();
        }

        public void InsertNode(int id)
        {
            cvorovi[id] = new Cvor(id);
        }

        public bool InsertEdge(int key1, int key2, int tezina)
        {
            if (this.graneHS.Contains((key1, key2)))
            {
                Console.WriteLine($"Vec postoji {key1} {key2}!");
                return false;
            }

            if (this.graneHS.Contains((key2, key1)))
            {
                Console.WriteLine($"Vec postoji {key2} {key1}!");
                return false;
            }

            Cvor? cvor1 = cvorovi[key1];
            Cvor? cvor2 = cvorovi[key2];

            if (cvor1 == null)
            {
                Console.WriteLine($"Cvor sa kljucem {key1} ne postoji!\n");
                return false;
            }

            if (cvor2 == null)
            {
                Console.WriteLine($"Cvor sa kljucem {key2} ne postoji!\n");
                return false;
            }

            grane.Add(new Grana(cvor1, cvor2, tezina));
            graneHS.Add((cvor1.Key, cvor2.Key));

            cvor1.Susedi.Add(cvor2);
            cvor2.Susedi.Add(cvor1);

            return true;
        }

        public void PrintGraph()
        {
            Console.WriteLine("Cvorovi:\n\n");
            foreach (var cvor in cvorovi.Values)
            {
                Console.WriteLine(cvor.GetTextual());
            }

            Console.WriteLine("\nGrane:");
            foreach (var grana in grane)
            {
                Console.WriteLine(grana.GetTextual());
            }
        }

        public List<Grana>? PrimSpreznoStablo(int pocetniCvorKey)
        {
            List<Grana> spreznoStablo = new List<Grana>();
            Cvor? pocetniCvor;

            //Ako prosledimo 0 kao key pocetnog cvora odabrace se nasumicni cvor kao pocetni
            //jer nam vrednosti kljuceva idu od 1...
            if (pocetniCvorKey == 0)
            {
                Random rand = new Random();
                pocetniCvorKey = rand.Next(1,this.cvorovi.Count+1);
                
            }

            pocetniCvor = this.cvorovi[pocetniCvorKey];

            if (pocetniCvor == null)
            {
                Console.WriteLine("Nije pronadjen cvor sa proslednjenom vrednoscu kljuca!");
                return null;
            }

            Console.WriteLine("Pocetni cvor je: " + pocetniCvor.GetTextual());

            BinomniHeap priorityQ = new BinomniHeap(true);

            foreach(Cvor c in this.cvorovi.Values)
            {
                c.Value = int.MaxValue - 1; //Umesto beskonacno, stavljamo svim cvorovima maxValue od int-a umanjen za 1
                                           //Da slucajno ne bi bilo konflika sa decreaseKey operacijom koja koristi int.maxValue
                priorityQ.Insert(c);
            }

            //Zakomentarisana stampanja su u svrhu debagiranja

            //Console.WriteLine("\n=====\nPrioritetni heap pre svega:\n=====\n");

            //priorityQ.PrintHeap();

            priorityQ.DecreaseIncreaseKey(pocetniCvorKey, 0); //Pocetnom cvoru stavljamo vrednost na 0

            //Console.WriteLine("\n=====\nPrioritetni heap posle decrease key na 0:\n=====\n");

            //priorityQ.PrintHeap();

            pocetniCvor.Parent = null;

            //Console.WriteLine("\n=====\nGraf pre svega:\n=====\n");

            //this.PrintGraph();

            while (!priorityQ.HeadNull)
            {
                Cvor? current = priorityQ.ExtractMinMax()!.Cvor;

                //Console.WriteLine($"\n=====\nTrenutni current: {current.GetTextual()}\n=====\n");

                //Kada izvucemo minimalni, znaci da mozemo izmedju njega i njegovog parenta granu ubaciti i MST!

                if (current.Parent != null)
                {
                    Grana? mstEdge = this.grane.Find(n =>
                        (n.Node1 == current && n.Node2 == current.Parent) ||
                        (n.Node1 == current.Parent && n.Node2 == current));
                    if (mstEdge != null)
                    {
                        spreznoStablo.Add(mstEdge);
                        //Console.WriteLine($"\n=====\nDodata grana: {mstEdge.GetTextual()}\n=====\n");
                    }
                }

                if (current == null)
                {
                    Console.WriteLine("Neocekivana greska pri extractMin u primovom algoritmu!");
                    return null;
                }

                foreach(Cvor c in current!.Susedi)
                {

                    Grana? grana = this.grane.Find(n => (n.Node1 == current && n.Node2 == c) || (n.Node1 == c && n.Node2 == current));

                    //Console.WriteLine($"\n=====\nPosmatramo granu: {grana.GetTextual()}\n=====\n");

                    if (grana == null)
                    {
                        Console.WriteLine("Neocekivana greska gde grana ne postoji izmedju suseda!");
                        return null;
                    }

                    if(priorityQ.Find(c.Key)!= null && grana.Weight < c.Value)
                    {
                        c.Parent = current;
                        //Console.WriteLine($"\n=====\n:Cvor c pre promene: {c.GetTextual()}\n");
                        priorityQ.DecreaseIncreaseKey(c.Key, grana.Weight);
                        //Console.WriteLine($"Cvor c posle promene: {c.GetTextual()}\n=====\n");

                    }
                }

                //Za potrebe debagiranja:

                //Console.WriteLine("\n*************************\n");

                //Console.WriteLine("\n=====\nGraf: \n=====\n");

                //this.PrintGraph();

                //Console.WriteLine("\n=====\nPrioritetni heap:\n=====\n");

                //priorityQ.PrintHeap();

            }

            //Console.WriteLine("\n=====\nGraf: \n=====\n");

            //this.PrintGraph();

            //Console.WriteLine("\n=====\nPrioritetni heap:\n=====\n");

            //priorityQ.PrintHeap();

            return spreznoStablo;
        }
    }

}

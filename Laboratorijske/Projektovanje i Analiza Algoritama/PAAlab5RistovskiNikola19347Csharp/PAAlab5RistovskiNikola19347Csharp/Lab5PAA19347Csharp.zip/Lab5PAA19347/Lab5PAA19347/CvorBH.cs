﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5PAA19347
{
    public class CvorBH
    {
        public Cvor? Cvor { get; set; }
        public int Value 
        { 
            get 
            {
                return Cvor == null ? 0 : Cvor.Value;
            }
            set
            {
                if(Cvor != null) 
                    Cvor.Value = value;
            }
        }
        public CvorBH? Parent { get; set; }
        public CvorBH? Sibling { get; set; }

        public CvorBH? Child { get; set; }

        public int Degree { get; set; }

        public CvorBH()
        {
            Cvor = new Cvor();
            Parent = null;
            Sibling = null;
            Child = null;
            Degree = 0;
        }

        public CvorBH(Cvor cvor)
        {
            Cvor = cvor;
            Parent = null;
            Sibling = null;
            Child = null;
            Degree = 0;
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5PAA19347
{
    public class Grana
    {
        public Cvor? Node1 { get; set; }
        public Cvor? Node2 { get; set; }
        public int Weight { get; set; }

        public Grana(Cvor node1, Cvor node2, int weight)
        {
            Node1 = node1;
            Node2 = node2;
            Weight = weight;
        }

        public Grana()
        {
            Weight = 1;
            Node1 = null;
            Node2 = null;
        }

        public string? GetTextual()
        {
            if (Node1 == null || Node2 == null)
                return null;
            return $"G: {this.Node1!.GetTextual()} === {this.Node2!.GetTextual()} [{this.Weight}]";
        }

        public override bool Equals(object? drugaGrana)
        {
            if (drugaGrana == null || drugaGrana.GetType() != this.GetType())
                return false;

            Grana other = (Grana)drugaGrana;
            return this.Node1!.Value == other.Node1!.Value &&
                   this.Node2!.Value == other.Node2!.Value &&
                   this.Weight == other.Weight;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Node1, Node2, Weight);
        }
    }
}
